"use strict";

const $ = id => document.getElementById(id);

const mainCanvas = $("mainCanvas");
const numberCanvas = $("numberCanvas");
const wordsCanvas = $("wordsCanvas");
const mainCtx = mainCanvas.getContext("2d");

let sourceImage = null;

/*
  إعدادات تقريبية مبنية على نموذج الصورة المرفقة.
  عند اختلاف تصميم النموذج عدّلها من قسم ضبط أماكن القص.
*/
const DEFAULT_CROP = {
  nx: 58.0, ny: 60.7, nw: 19.0, nh: 3.8,
  wx: 20.0, wy: 60.6, ww: 31.0, wh: 3.8
};

for (const [key, value] of Object.entries(DEFAULT_CROP)) {
  $(key).value = value;
}

["nx","ny","nw","nh","wx","wy","ww","wh"].forEach(id => {
  $(id).addEventListener("input", renderAll);
});

$("fileInput").addEventListener("change", loadImage);
$("scanButton").addEventListener("click", runScan);
$("resetButton").addEventListener("click", () => location.reload());
$("numberText").addEventListener("input", compareCurrentValues);
$("wordsText").addEventListener("input", compareCurrentValues);

function getCrop(prefix) {
  return {
    x: Number($(prefix + "x").value) / 100,
    y: Number($(prefix + "y").value) / 100,
    w: Number($(prefix + "w").value) / 100,
    h: Number($(prefix + "h").value) / 100
  };
}

function loadImage(event) {
  const file = event.target.files && event.target.files[0];
  if (!file) return;

  const reader = new FileReader();

  reader.onload = e => {
    sourceImage = new Image();

    sourceImage.onload = () => {
      const displayScale = Math.min(1, 1100 / sourceImage.naturalWidth);

      mainCanvas.width = Math.round(sourceImage.naturalWidth * displayScale);
      mainCanvas.height = Math.round(sourceImage.naturalHeight * displayScale);

      $("scanButton").disabled = false;
      $("progressText").textContent = "الصورة جاهزة";
      setResult("wait", "الصورة جاهزة. اضغط «ابدأ التدقيق».");

      renderAll();
    };

    sourceImage.src = e.target.result;
  };

  reader.readAsDataURL(file);
}

function renderAll() {
  if (!sourceImage) return;

  mainCtx.clearRect(0, 0, mainCanvas.width, mainCanvas.height);
  mainCtx.drawImage(sourceImage, 0, 0, mainCanvas.width, mainCanvas.height);

  const numberCrop = getCrop("n");
  const wordsCrop = getCrop("w");

  drawOverlay(numberCrop, "#d00000");
  drawOverlay(wordsCrop, "#005bd6");

  cropAtOriginalResolution(numberCrop, numberCanvas, "number");
  cropAtOriginalResolution(wordsCrop, wordsCanvas, "words");
}

function drawOverlay(rect, color) {
  mainCtx.save();
  mainCtx.strokeStyle = color;
  mainCtx.lineWidth = 3;
  mainCtx.setLineDash([9, 5]);

  mainCtx.strokeRect(
    rect.x * mainCanvas.width,
    rect.y * mainCanvas.height,
    rect.w * mainCanvas.width,
    rect.h * mainCanvas.height
  );

  mainCtx.restore();
}

/*
  النقطة الأساسية هنا:
  القص يتم من الصورة الأصلية naturalWidth/naturalHeight،
  وليس من صورة العرض المصغرة. لذلك لا نفقد الدقة.
*/
function cropAtOriginalResolution(rect, targetCanvas, mode) {
  const sx = Math.max(0, Math.round(rect.x * sourceImage.naturalWidth));
  const sy = Math.max(0, Math.round(rect.y * sourceImage.naturalHeight));
  const sw = Math.max(1, Math.round(rect.w * sourceImage.naturalWidth));
  const sh = Math.max(1, Math.round(rect.h * sourceImage.naturalHeight));

  const rawCanvas = document.createElement("canvas");
  rawCanvas.width = sw;
  rawCanvas.height = sh;

  const rawCtx = rawCanvas.getContext("2d", { willReadFrequently: true });
  rawCtx.imageSmoothingEnabled = false;
  rawCtx.drawImage(
    sourceImage,
    sx, sy, sw, sh,
    0, 0, sw, sh
  );

  if (window.cv && window.cv.Mat) {
    enhanceWithOpenCV(rawCanvas, targetCanvas, mode);
  } else {
    enhanceFallback(rawCanvas, targetCanvas, mode);
  }
}

function enhanceWithOpenCV(rawCanvas, outputCanvas, mode) {
  let src = null;
  let gray = null;
  let resized = null;
  let denoised = null;
  let binary = null;
  let kernel = null;

  try {
    src = cv.imread(rawCanvas);
    gray = new cv.Mat();
    resized = new cv.Mat();
    denoised = new cv.Mat();
    binary = new cv.Mat();

    cv.cvtColor(src, gray, cv.COLOR_RGBA2GRAY);

    const upscale = mode === "number" ? 4 : 3;
    const targetSize = new cv.Size(
      Math.max(1, gray.cols * upscale),
      Math.max(1, gray.rows * upscale)
    );

    cv.resize(gray, resized, targetSize, 0, 0, cv.INTER_CUBIC);

    cv.GaussianBlur(
      resized,
      denoised,
      new cv.Size(3, 3),
      0,
      0,
      cv.BORDER_DEFAULT
    );

    if (mode === "number") {
      cv.adaptiveThreshold(
        denoised,
        binary,
        255,
        cv.ADAPTIVE_THRESH_GAUSSIAN_C,
        cv.THRESH_BINARY,
        31,
        10
      );

      /*
        فتح مورفولوجي خفيف لتقليل خطوط المربعات الدقيقة
        بدون تدمير الأرقام.
      */
      kernel = cv.getStructuringElement(
        cv.MORPH_RECT,
        new cv.Size(2, 2)
      );

      cv.morphologyEx(
        binary,
        binary,
        cv.MORPH_OPEN,
        kernel
      );
    } else {
      cv.threshold(
        denoised,
        binary,
        0,
        255,
        cv.THRESH_BINARY + cv.THRESH_OTSU
      );
    }

    outputCanvas.width = binary.cols;
    outputCanvas.height = binary.rows;
    cv.imshow(outputCanvas, binary);

  } catch (error) {
    console.error("OpenCV processing failed:", error);
    enhanceFallback(rawCanvas, outputCanvas, mode);
  } finally {
    if (src) src.delete();
    if (gray) gray.delete();
    if (resized) resized.delete();
    if (denoised) denoised.delete();
    if (binary) binary.delete();
    if (kernel) kernel.delete();
  }
}

function enhanceFallback(rawCanvas, outputCanvas, mode) {
  const scale = mode === "number" ? 4 : 3;

  outputCanvas.width = rawCanvas.width * scale;
  outputCanvas.height = rawCanvas.height * scale;

  const ctx = outputCanvas.getContext("2d", { willReadFrequently: true });

  ctx.imageSmoothingEnabled = true;
  ctx.imageSmoothingQuality = "high";
  ctx.filter = mode === "number"
    ? "grayscale(1) contrast(2.4) brightness(1.15)"
    : "grayscale(1) contrast(1.9) brightness(1.1)";

  ctx.drawImage(
    rawCanvas,
    0, 0, rawCanvas.width, rawCanvas.height,
    0, 0, outputCanvas.width, outputCanvas.height
  );

  ctx.filter = "none";
}

async function runScan() {
  if (!sourceImage) return;

  if (typeof Tesseract === "undefined") {
    setResult("bad", "تعذر تحميل Tesseract.js. تأكد من اتصال الإنترنت.");
    return;
  }

  $("scanButton").disabled = true;
  $("progress").value = 0;
  setResult("wait", "جاري التدقيق...");

  try {
    $("progressText").textContent = "قراءة المبلغ الرقمي";

    const numberAttempts = [];

    numberAttempts.push(
      await recognize(numberCanvas, "eng", 7, "0123456789٠١٢٣٤٥٦٧٨٩")
    );

    numberAttempts.push(
      await recognize(numberCanvas, "ara+eng", 6, "0123456789٠١٢٣٤٥٦٧٨٩")
    );

    numberAttempts.push(
      await recognize(numberCanvas, "eng", 11, "0123456789٠١٢٣٤٥٦٧٨٩")
    );

    const bestNumber = chooseBestNumber(numberAttempts);
    $("numberText").value = bestNumber.text;

    $("progressText").textContent = "قراءة المبلغ المكتوب";

    const writtenText = await recognize(wordsCanvas, "ara", 7);
    $("wordsText").value = writtenText.trim();

    compareCurrentValues();

    $("progress").value = 1;
    $("progressText").textContent = "انتهت القراءة";

  } catch (error) {
    console.error(error);
    setResult(
      "bad",
      "فشل OCR. راجع اتصال الإنترنت، جودة الصورة، وحدود القص."
    );
  } finally {
    $("scanButton").disabled = false;
  }
}

async function recognize(canvas, language, psm, whitelist = null) {
  const options = {
    logger: updateProgress,
    tessedit_pageseg_mode: String(psm),
    preserve_interword_spaces: "1"
  };

  if (whitelist) {
    options.tessedit_char_whitelist = whitelist;
  }

  const result = await Tesseract.recognize(
    canvas,
    language,
    options
  );

  return result.data.text.trim();
}

function updateProgress(message) {
  if (typeof message.progress !== "number") return;

  $("progress").value = message.progress;

  const percent = Math.round(message.progress * 100);
  $("progressText").textContent =
    (message.status || "جاري المعالجة") + " — " + percent + "%";
}

function chooseBestNumber(attempts) {
  const candidates = attempts.map(text => ({
    text,
    value: extractNumericAmount(text)
  })).filter(item =>
    item.value !== null &&
    Number.isFinite(item.value) &&
    item.value >= 0 &&
    item.value <= 999999999
  );

  if (!candidates.length) {
    return { text: attempts[0] || "", value: null };
  }

  /*
    نفضّل:
    1) قيمة ليست صفرًا.
    2) نصًا يحتوي أرقامًا أكثر.
    3) قيمة منطقية وغير ضخمة.
  */
  candidates.sort((a, b) => {
    const aDigits = normalizeDigits(a.text).replace(/\D/g, "").length;
    const bDigits = normalizeDigits(b.text).replace(/\D/g, "").length;

    if ((b.value > 0) !== (a.value > 0)) {
      return b.value > 0 ? 1 : -1;
    }

    return bDigits - aDigits;
  });

  return candidates[0];
}

function normalizeDigits(text) {
  const map = {
    "٠":"0","١":"1","٢":"2","٣":"3","٤":"4",
    "٥":"5","٦":"6","٧":"7","٨":"8","٩":"9",
    "۰":"0","۱":"1","۲":"2","۳":"3","۴":"4",
    "۵":"5","۶":"6","۷":"7","۸":"8","۹":"9"
  };

  return String(text || "").replace(/[٠-٩۰-۹]/g, digit => map[digit]);
}

function extractNumericAmount(text) {
  let cleaned = normalizeDigits(text)
    .replace(/[^\d]/g, "");

  if (!cleaned) return null;

  cleaned = cleaned.replace(/^0+/, "") || "0";

  const value = Number(cleaned);
  return Number.isFinite(value) ? value : null;
}

function normalizeArabic(text) {
  return String(text || "")
    .replace(/[إأآٱ]/g, "ا")
    .replace(/ى/g, "ي")
    .replace(/ة/g, "ه")
    .replace(/[ًٌٍَُِّْـ]/g, "")
    .replace(/[^\u0600-\u06FF\s]/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

const SMALL_NUMBERS = {
  "صفر":0,
  "واحد":1,"واحده":1,"احد":1,"احدى":1,
  "اثنان":2,"اثنين":2,"اثنا":2,"اثني":2,"اثنتان":2,"اثنتين":2,
  "ثلاث":3,"ثلاثه":3,
  "اربع":4,"اربعه":4,
  "خمس":5,"خمسه":5,
  "ست":6,"سته":6,
  "سبع":7,"سبعه":7,
  "ثمان":8,"ثماني":8,"ثمانيه":8,
  "تسع":9,"تسعه":9,

  "عشر":10,"عشره":10,
  "احدعشر":11,"احدىعشره":11,
  "اثناعشر":12,"اثنيعشر":12,"اثنتاعشره":12,"اثنتيعشره":12,
  "ثلاثهعشر":13,"ثلاثعشره":13,
  "اربعهعشر":14,"اربععشره":14,
  "خمسهعشر":15,"خمسعشره":15,
  "ستهعشر":16,"ستعشره":16,
  "سبعهعشر":17,"سبععشره":17,
  "ثمانيهعشر":18,"ثمانيعشره":18,
  "تسعهعشر":19,"تسععشره":19,

  "عشرون":20,"عشرين":20,
  "ثلاثون":30,"ثلاثين":30,
  "اربعون":40,"اربعين":40,
  "خمسون":50,"خمسين":50,
  "ستون":60,"ستين":60,
  "سبعون":70,"سبعين":70,
  "ثمانون":80,"ثمانين":80,
  "تسعون":90,"تسعين":90,

  "مئه":100,"مائه":100,
  "مئتان":200,"مئتين":200,"مائتان":200,"مائتين":200,
  "ثلاثمئه":300,"ثلاثمائه":300,
  "اربعمئه":400,"اربعمائه":400,
  "خمسمئه":500,"خمسمائه":500,
  "ستمئه":600,"ستمائه":600,
  "سبعمئه":700,"سبعمائه":700,
  "ثمانمئه":800,"ثمانمائه":800,
  "تسعمئه":900,"تسعمائه":900
};

const SCALES = {
  "الف":1000,
  "الاف":1000,
  "مليون":1000000,
  "ملايين":1000000,
  "مليار":1000000000,
  "مليارات":1000000000
};

const FIXED_SCALES = {
  "الفان":2000,
  "الفين":2000,
  "مليونان":2000000,
  "مليونين":2000000,
  "ملياران":2000000000,
  "مليارين":2000000000
};

function tokenizeArabicNumber(text) {
  let normalized = normalizeArabic(text)
    .replace(/\b(فقط|لا|غير|لاغير|ريال|ريالا|ريالات|سعودي|سعوديه|هلله|هللات)\b/g, " ")
    .replace(/\s+/g, " ")
    .trim();

  let tokens = normalized.split(" ").filter(Boolean);

  tokens = tokens.map(token => {
    if (token.length > 1 && token.startsWith("و")) {
      return token.slice(1);
    }
    return token;
  });

  const joined = [];

  for (let i = 0; i < tokens.length; i++) {
    const pair = tokens[i] + (tokens[i + 1] || "");

    if (SMALL_NUMBERS[pair] !== undefined) {
      joined.push(pair);
      i++;
    } else {
      joined.push(tokens[i]);
    }
  }

  return joined;
}

function arabicWordsToNumber(text) {
  const tokens = tokenizeArabicNumber(text);

  if (!tokens.length) return null;

  let total = 0;
  let current = 0;
  let recognized = 0;

  for (const token of tokens) {
    if (SMALL_NUMBERS[token] !== undefined) {
      current += SMALL_NUMBERS[token];
      recognized++;
      continue;
    }

    if (FIXED_SCALES[token] !== undefined) {
      total += FIXED_SCALES[token];
      current = 0;
      recognized++;
      continue;
    }

    if (SCALES[token] !== undefined) {
      total += (current || 1) * SCALES[token];
      current = 0;
      recognized++;
    }
  }

  if (!recognized) return null;

  return total + current;
}

function compareCurrentValues() {
  const numeric = extractNumericAmount($("numberText").value);
  const written = arabicWordsToNumber($("wordsText").value);

  $("numberValue").textContent =
    numeric === null ? "تعذر الاستخراج" : numeric.toLocaleString("ar-SA");

  $("wordsValue").textContent =
    written === null ? "تعذر التحويل" : written.toLocaleString("ar-SA");

  if (numeric === null || written === null) {
    setResult(
      "bad",
      "تعذر استخراج إحدى القيم. راجع النص المقروء أو عدّل حدود القص."
    );
    return;
  }

  if (numeric === written) {
    setResult(
      "ok",
      "✅ المبلغ متطابق: " + numeric.toLocaleString("ar-SA") + " ريال."
    );
  } else {
    setResult(
      "bad",
      "❌ المبلغ غير متطابق — الرقم: " +
      numeric.toLocaleString("ar-SA") +
      "، والكتابة: " +
      written.toLocaleString("ar-SA") +
      "."
    );
  }
}

function setResult(type, message) {
  const box = $("result");
  box.className = "status " + type;
  box.textContent = message;
}
